using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class JoelV2 : MonoBehaviour
{
    public Material highlightMaterial;
    public Material selectionMaterial;

    private Material originalMaterialHighlight;
    private Material originalMaterialSelection;
    private Transform highlight;
    [SerializeField] bool click;
    private Transform selection;
    private RaycastHit raycastHit;
    [SerializeField] GameObject JoelUI;


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X))
        {
            JoelUI.SetActive(false);

        }
        if (highlight != null)
        {
            highlight = null;
        }
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (!EventSystem.current.IsPointerOverGameObject() && Physics.Raycast(ray, out raycastHit)) //Make sure you have EventSystem in the hierarchy before using EventSystem
        {
            highlight = raycastHit.transform;
            if (highlight.CompareTag("Joel") && highlight != selection)
            {

            }
            else
            {
                highlight = null;
            }

        }

        // Selection
        if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            if (highlight)
            {
                if (selection != null)
                {

                }
                selection = raycastHit.transform;
                if (click == false)
                {
                    JoelUI.SetActive(!JoelUI.gameObject.activeSelf);
                }
                highlight = null;
            }
            else
            {
                if (selection)
                {
                    JoelUI.SetActive(!JoelUI.gameObject.activeSelf);
                    selection = null;
                }
            }
        }

    }


}
