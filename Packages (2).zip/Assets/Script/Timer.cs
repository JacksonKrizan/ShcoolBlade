using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Timer : MonoBehaviour
{
    [SerializeField] Text tim;
    [SerializeField] private float seconds;
    public int timevbn;
    [SerializeField] private bool deleteBlock;
    [SerializeField] private bool EndOfGame = false;
    public bool gameOn = true;
    void Start()
    {
        StartCoroutine(Endtimer());
        StartCoroutine(CountDown());
    }

    IEnumerator CountDown()
    {
        yield return new WaitForSeconds(1);
        timevbn -= 1;
        if (gameOn == true)
        {
            StartCoroutine(CountDown());
        }
        
    }

    IEnumerator Endtimer()
    {
        yield return new WaitForSeconds(timevbn);
        deleteBlock = true;
    }

    void Update()
    {

        tim.text = "" + timevbn;
        if (deleteBlock == true)
        {
            //Destroy(this.gameObject);
            EndOfGame = true;
        }

        if (timevbn == 1)
        {
            gameOn = false;
            //tim.text = " ";
        }


    }
}
