Urban Night Sky is a free to use asset containing textures of a nightsky that can be used for a skybox (6 sided).

When placing the textures, make sure they are put in their respective spots within the skybox material you are making.
	- NightUrbanSky_Top should be placed on the Up side, NightUrbanSky_Front should be placed on the front side, etc.