using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Timer : MonoBehaviour
{
    [SerializeField] Text tim;
    [SerializeField] private float seconds;
    [SerializeField] private int timevbn;
    [SerializeField] private bool deleteBlock;
    [SerializeField] private bool EndOfGame = false;
    void Start()
    {
        StartCoroutine(Endtimer());
        StartCoroutine(CountDown());
    }

    IEnumerator CountDown()
    {
        yield return new WaitForSeconds(1);
        timevbn -= 1;
        StartCoroutine(CountDown());
    }

    IEnumerator Endtimer()
    {
        yield return new WaitForSeconds(timevbn);//30 min
        deleteBlock = true;
    }

    void Update()
    {

        tim.text = "" + timevbn;
        if (deleteBlock == true)
        {
            Destroy(this.gameObject);
            EndOfGame = true;
        }

        if (timevbn == 0)
        {
            tim.text = " ";
        }


    }
}
