using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Joel1 : MonoBehaviour
{
    public Material highlightMaterial;
    public Material selectionMaterial;

    private Material originalMaterialHighlight;
    private Material originalMaterialSelection;
    private Transform highlight;
    private Transform selection;
    private RaycastHit raycastHit;
    [SerializeField] GameObject JoelUI;


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X))
        {
            JoelUI.SetActive(false);

        }
        // Highlight
        if (highlight != null)
        {
            //Debug.Log("1");
            //highlight.GetComponent<MeshRenderer>().sharedMaterial = originalMaterialHighlight;
            highlight = null;
        }
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (!EventSystem.current.IsPointerOverGameObject() && Physics.Raycast(ray, out raycastHit)) //Make sure you have EventSystem in the hierarchy before using EventSystem
        {
            highlight = raycastHit.transform;
            if (highlight.CompareTag("Joel") && highlight != selection)
            {
                //if (highlight.GetComponent<MeshRenderer>().material != highlightMaterial)
                //{
                   // originalMaterialHighlight = highlight.GetComponent<MeshRenderer>().material;
                    //highlight.GetComponent<MeshRenderer>().material = highlightMaterial;
                   // Debug.Log("2");
                //}
            }
            else
            {
                highlight = null;
                //Debug.Log("3");
            }

        }

        // Selection
        if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            if (highlight)
            {
                if (selection != null)
                {
                    //Debug.Log("4");
                    //selection.GetComponent<MeshRenderer>().material = originalMaterialSelection;
                }
                selection = raycastHit.transform;
                if (selection.GetComponent<MeshRenderer>().material != selectionMaterial)
                {
                    //Debug.Log("5");
                    JoelUI.SetActive(!JoelUI.gameObject.activeSelf);
                    //Debug.Log("2");
                    //originalMaterialSelection = originalMaterialHighlight;
                    //selection.GetComponent<MeshRenderer>().material = selectionMaterial;
                }
                highlight = null;
            }
            else
            {
                if (selection)
                {
                    //Debug.Log("6");
                    JoelUI.SetActive(!JoelUI.gameObject.activeSelf);
                    //selection.GetComponent<MeshRenderer>().material = originalMaterialSelection;
                    selection = null;
                }
            }
        }

    }


}
