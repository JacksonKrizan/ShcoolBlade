using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Array : MonoBehaviour
{
    //Example 1
    //int _number = 12;
    //int[] _numberArray = new int[4];

    //Example 2
    string[] name = { "Arthur", "Dorothea", "Carl", "Joel" };
    string[] timesStamp = {"6:00 AM at Work", "12:00 PM at Bowling Alley", "3:00 AM at a Party", "1:00 AM at Home"};
    string[] height = { "5'5 Short ", "", "", "", "", "", };
    string[] shoeSize = { "5'5 Short ", "", "", "", "", "", };
    string[] shoePrint = { "5'5 Short ", "", "", "", "", "", };
    string[] fingerprint = { "5'5 Short ", "", "", "", "", "", };




    public int killerName;
    public int killerTime;
    public int killerHeight;
    public int killerShoeSize;
    public int killerShoePrints;
    public int killerFingerprints;



    //Example 3
    //public GameObject[] _killers;

    // Start is called before the first frame update
    void Start()
    {
        killerName = Random.Range(0, 4);
        killerTime = Random.Range(0, 4);
        killerHeight = Random.Range(0, 4);
        killerShoeSize = Random.Range(0, 4);
        killerShoePrints = Random.Range(0, 4);
        killerFingerprints = Random.Range(0, 4);

        //_numberArray[0] = 19;
        //_numberArray[1] = 156;
        //_numberArray[2] = 23;
        //_numberArray[3] = 80;

        //Debug.Log(_names[killerName]);
    }

    // Update is called once per frame
    void Update()
    {


        Debug.Log(name[killerName]);
        Debug.Log(timesStamp[killerTime]);

        //Debug.Log(killerName);
        //Debug.Log(killerHeight);
    }
}
