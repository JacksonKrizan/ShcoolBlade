using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static UnityEditor.Timeline.TimelinePlaybackControls;
using UnityEngine.UIElements;

public class Timer : MonoBehaviour
{
    [SerializeField] Text timer;
    [SerializeField] private float seconds;
    [SerializeField] private int time;
    [SerializeField] private bool deleteBlock;
    [SerializeField] private bool EndOfGame = false;
    void Start()
    {
        StartCoroutine(Endtimer());
        StartCoroutine(CountDown());
    }

    IEnumerator CountDown()
    {
        yield return new WaitForSeconds(1);
        time -= 1;
        StartCoroutine(CountDown());
    }

    IEnumerator Endtimer()
    {
        yield return new WaitForSeconds(time);//30 min
        deleteBlock = true;
    }

    void Update()
    {

        timer.text = "" + time;
        if (deleteBlock == true)
        {
            Destroy(this.gameObject);
            EndOfGame = true;
        }

        if (time == 0)
        {
            timer.text = " ";
        }


    }
}
